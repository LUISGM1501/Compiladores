# /Etapa1/codigo/scanner/__init__.py
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Paquete scanner - Analizador léxico para el lenguaje MC
"""

from .core import Scanner
from .tokens import Token