from ..Simbolo import Simbolo
from ..TablaSimbolos import TablaSimbolo